# jokes_topics modeling
A study to identify the topics of jokes in Russian. Various token vectorization tools from the Natural Language Processing (NLP) arsenal were used.
Article published on habr.com
